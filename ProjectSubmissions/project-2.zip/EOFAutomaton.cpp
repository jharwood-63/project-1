//
// Created by jharw on 9/15/2021.
//

#include "EOFAutomaton.h"
void EOFAutomaton::S0(const std::string& input) {
    Serr();
}