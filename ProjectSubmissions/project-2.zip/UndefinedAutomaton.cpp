//
// Created by jharw on 9/15/2021.
//

#include "UndefinedAutomaton.h"

void UndefinedAutomaton::S0(const std::string& input) {
    Serr();
}